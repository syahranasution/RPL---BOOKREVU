<div class="container-fluid">
    <div class="row">
        <h2 style="color: #87CEEB; font-family: Ink free;"><i class="fas fa-home"></i><b> Dashboard</b></h2><hr>
    </div>
    <div class="row d-flex flex-row justify-content-around">
        <div class="card col-md-2 text-white bg-primary-color mt-3" onclick="location.href = 'index.php?show=admin';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Admin</b></h4>
                    <i class="fas fa-user-lock fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data : <?= $koneksi_db->query("SELECT count(*) FROM admin")->fetch_array()[0] ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = 'index.php?show=ongkir';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Ongkir</b></h4>
                    <i class="fas fa-shipping-fast fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $koneksi_db->query("SELECT count(*) FROM ongkir")->fetch_array()[0] ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = 'index.php?show=pelanggan';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Customer</b></h4>
                    <i class="fas fa-users fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $koneksi_db->query("SELECT count(*) FROM pelanggan")->fetch_array()[0] ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = 'index.php?show=produk';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Produk</b></h4>
                    <i class="fas fa-utensils fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $koneksi_db->query("SELECT count(*) FROM tbl_produk")->fetch_array()[0] ?>
                </div>
            </div>
        </div>
    </div>
</div>