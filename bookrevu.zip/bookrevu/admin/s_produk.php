<?php
    session_start();
    require '../koneksi.php';
    if(isset($_POST['action'])){
        print_r($_POST);
        $action = $_POST['action'];
        $id = $_POST['id'];
        $nama = $_POST['nama_produk'];
        $harga = $_POST['harga_produk'];
        $deskripsi = $_POST['deskripsi_produk'];
        if($_FILES['foto_produk']['size'] > 0){
            print_r($_FILES);
            $image_flag = true;
            $file = $_FILES['foto_produk']['name'];
            $tempFile = $_FILES['foto_produk']['tmp_name'];

            //membuat nama file
            $name = $_POST['nama_produk'] . '_' . time() . '.' . str_replace('image/', '', $_FILES['foto_produk']['type']);

            // tentukan lokasi file akan dipindahkan
            $dir = "../img/";
            
            // pindahkan file
            $uploaded = move_uploaded_file($tempFile, $dir.$name);
        }
    
        if($action == 'edit'){
            if(isset($image_flag)){
                $query = mysqli_query($koneksi_db, "UPDATE tbl_produk SET harga_produk = '$harga', nama_produk = '$nama', deskripsi_produk = '$deskripsi', foto_produk = '$name' WHERE id_produk = $id");
            }else{
                $query = mysqli_query($koneksi_db, "UPDATE tbl_produk SET harga_produk = '$harga', nama_produk = '$nama', deskripsi_produk = '$deskripsi' WHERE id_produk = $id");
            }
        }else if($action == 'baru'){
            if(isset($image_flag)){
                $query = mysqli_query($koneksi_db, "INSERT INTO tbl_produk (id_produk, harga_produk, nama_produk, deskripsi_produk, foto_produk) VALUES('$id', '$harga', '$nama', '$deskripsi', '$name');");
            }else{
                // $query = mysqli_query($koneksi_db, "INSERT INTO tbl_produk (id_produk, harga_produk, nama_produk, deskripsi_produk) VALUES('$id', '$harga', '$nama', '$deskripsi');");
                header('Location: index.php?show=produk&error=2');
                exit();
            }
        }
    }else if(isset($_GET['action'])){
        $action = $_GET['action'];
        $id = $_GET['id'];
        if($action == 'hapus'){
            $query = mysqli_query($koneksi_db, "DELETE FROM tbl_produk WHERE id_produk=$id");
        }
    }
    if($query){
        header('Location: index.php?show=produk');
    }else{
        print_r(mysqli_error($koneksi_db));
        header('Location: index.php?show=produk&error=1');
    }
?>