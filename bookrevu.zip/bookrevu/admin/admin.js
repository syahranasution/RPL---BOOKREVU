function hapus_data(action, id) {
    if (confirm(`Hapus data dengan ID: ${id} ?`)) {
        window.location.href = `s_${action}.php?action=hapus&id=${id}`;
    }
}
$(document).ready(function () {
});