<?php
    session_start();
    require '../koneksi.php';
    if(isset($_POST['action'])){
        print_r($_POST);
        $action = $_POST['action'];
        $id = $_POST['id'];
        $username = $_POST['username'];
        $nama = $_POST['nama_lengkap'];
        if($_POST['password'] != ''){
            $pass = $_POST['password'];
            $pass_c = $_POST['password_c'];
            if($pass != $pass_c){
                header('Location: index.php?show=admin&error=2');
                exit();
            }
        }
    
        if($action == 'edit'){
            if(isset($pass)){
                $query = mysqli_query($koneksi_db, "UPDATE admin SET username = '$username', nama_lengkap = '$nama', password = '$pass' WHERE id_admin = $id");
            }else{
                $query = mysqli_query($koneksi_db, "UPDATE admin SET username = '$username', nama_lengkap = '$nama' WHERE id_admin = $id");
            }
        }else if($action == 'baru'){
            $query = mysqli_query($koneksi_db, "INSERT INTO admin (id_admin, username, nama_lengkap, password) VALUES('$id', '$username', '$nama', '$pass');");
        }
    }else if(isset($_GET['action'])){
        $action = $_GET['action'];
        $id = $_GET['id'];
        if($action == 'hapus'){
            $query = mysqli_query($koneksi_db, "DELETE FROM admin WHERE id_admin=$id");
        }
    }
    if($query){
        header('Location: index.php?show=admin');
    }else{
        print_r(mysqli_error($koneksi_db));
        header('Location: index.php?show=admin&error=1');
    }
?>