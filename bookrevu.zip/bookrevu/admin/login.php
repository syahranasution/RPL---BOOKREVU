<?php
    require"../koneksi.php";
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        $ambil = $koneksi_db->query("SELECT * FROM admin WHERE username = '$username' AND password = '$password'");

        if ($ambil->num_rows) 
        {
            $admin = $ambil->fetch_assoc();
            session_start();
            $_SESSION["admin"] = $admin;
            header("location: index.php");
        }else{
            header("location: index.php");
        }
    }
?>
<h2>Silahkan Login</h2>
<form action="login.php" method="post">
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" name="username" id="username" required>
    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password" id="password" required>
    </div>
    <div class="form-group">
        <input type="submit" class="form-control btn btn-primary" name="login" value="Login">
    </div>
    <div class="form-group">
        <button type="button" class="form-control btn btn-danger" onclick="window.history.back();">Cancel</button>
    </div>
</form>