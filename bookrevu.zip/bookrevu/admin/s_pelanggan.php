<?php
    session_start();
    require '../koneksi.php';
    if(isset($_POST['action'])){
        print_r($_POST);
        $action = $_POST['action'];
        $id = $_POST['id'];
        $email = $_POST['email_pelanggan'];
        $nama = $_POST['nama_pelanggan'];
        $telp = $_POST['telpon_pelanggan'];
        $level = $_POST['level'];
    
        if($action == 'edit'){
            $query = mysqli_query($koneksi_db, "UPDATE pelanggan SET email_pelanggan = '$email', nama_pelanggan = '$nama', telpon_pelanggan = '$telp', level='$level' WHERE id_pelanggan = $id");
        }else if($action == 'baru'){
            $query = mysqli_query($koneksi_db, "INSERT INTO pelanggan (id_pelanggan, email_pelanggan, nama_pelanggan, telpon_pelanggan, level) VALUES('$id', '$email', '$nama', '$telp', '$level');");
        }
    }else if(isset($_GET['action'])){
        $action = $_GET['action'];
        $id = $_GET['id'];
        if($action == 'hapus'){
            $query = mysqli_query($koneksi_db, "DELETE FROM pelanggan WHERE id_pelanggan=$id");
        }
    }
    if($query){
        header('Location: index.php?show=pelanggan');
    }else{
        print_r(mysqli_error($koneksi_db));
        header('Location: index.php?show=pelanggan&error=1');
    }
?>