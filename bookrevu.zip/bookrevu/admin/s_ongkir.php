<?php
    session_start();
    require '../koneksi.php';
    if(isset($_POST['action'])){
        print_r($_POST);
        $action = $_POST['action'];
        $id = $_POST['id'];
        $kota = $_POST['nama_kota'];
        $tarif = $_POST['tarif'];
    
        if($action == 'edit'){
            $query = mysqli_query($koneksi_db, "UPDATE ongkir SET nama_kota = '$kota', tarif = $tarif WHERE id_ongkir = $id");
        }else if($action == 'baru'){
            $query = mysqli_query($koneksi_db, "INSERT INTO ongkir (id_ongkir, nama_kota, tarif) VALUES('$id', '$kota', $tarif);");
        }
    }else if(isset($_GET['action'])){
        print_r($_GET);
        $action = $_GET['action'];
        $id = $_GET['id'];
        if($action == 'hapus'){
            $query = mysqli_query($koneksi_db, "DELETE FROM ongkir WHERE id_ongkir=$id");
        }
    }
    if($query){
        header('Location: index.php?show=ongkir');
    }else{
        print_r(mysqli_error($koneksi_db));
        header('Location: index.php?show=ongkir&error=1');
    }
?>