    <header class="header-admin">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-12 col-12">
            <!-- <div class="btn-group">
              <button class="btn my-md-4 my-2 text-white"><i class="fab fa-facebook-square m-2"></i></button>
              <button class="btn my-md-4 my-2 text-white"><i class="fab fa-instagram"></i></button>
              <button class="btn my-md-4 my-2 text-white"><i class="fab fa-youtube"></i></button>
            </div> -->
          </div>

            <div class="col-md-4 col-12 text-center">
               <h2 class="my-md-3 site-title text-white"><i class="fas fa-user-lock" data-toggle="tolltip" title="Sign In"></i>  | Halaman Admin</h2>
            </div>
       </div>
      </div>
    </header>

    <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-admin">
      <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
          <a class="nav-link active ml-2" href="index.php"><i class="fas fa-home fa-lg" data-toggle="tooltip" title="Dashboard"></i><span class="sr-only">(current)</span></a>
          <a class="nav-link ml-2" href="?show=admin"><i class="fas fa-unlock-alt fa-lg" data-toggle="tooltip" title="Admin"></i></a>
          <a class="nav-link ml-2" href="?show=ongkir"><i class="fas fa-shipping-fast fa-lg" data-toggle="tooltip" title="ongkir"></i></a>
          <a class="nav-link ml-2" href="?show=pelanggan"><i class="fas fa-user fa-lg" data-toggle="tooltip" title="Pelanggan"></i></a>
          <a class="nav-link ml-2" href="?show=produk"><i class="fas fa-utensils fa-lg" data-toggle="tooltip" title="Produk"></i></a>
          <a class="nav-link ml-2" href="?show=pembelian"><i class="fas fa-cash-register fa-lg" data-toggle="tooltip" title="Pembelian"></i></a>
          <a class="nav-link ml-2" href="?show=laporan"><i class="fas fa-file fa-lg" data-toggle="tooltip" title="Laporan"></i></a>
        </div>
      </div>

    </nav>

    <div class="row no-gutters">
        <div class="col-md-2 bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="list-group list-group-flush">
              <li class="list-group-item" style="background-color: var(--primary-color) !important; color: white;"><i class="fas fa-list-ul m-2"></i>ADMIN</li><br>
              <img src="img/admin.jpg" width="200"><br>
              <a href="index.php" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-home p-2"></i>DASHBOARD</a>
              <a href="?show=admin" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-user-lock p-2"></i>ADMIN</a>
              <a href="?show=ongkir" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-shipping-fast p-2"></i>ONGKIR</a>
              <a href="?show=pelanggan" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-user p-2"></i>PELANGGAN</a>
              <a href="?show=produk" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-utensils p-2"></i>PRODUK</a>
              <a href="?show=pembelian" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-cash-register p-2"></i>PEMBELIAN</a>
              <a href="?show=laporan" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-file p-2"></i>LAPORAN</a>
              <a href="logout.php" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-tachometer-alt m-2"></i>LOGOUT</a>
            </ul>
          </div>
      </div>
    </div>