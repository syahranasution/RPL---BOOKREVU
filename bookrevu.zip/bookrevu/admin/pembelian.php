<h3 style="color: var(--primary-color) !important; font-family: Ink Free;"><i class="fas fa-cash-register mt-2"></i> <b>Data Pembelian</b></h3><hr>
       <table class="table table-striped" style="background-color: var(--primary-color) !important; font-family: Ink Free; width: 1000px; margin-left: 20px;">
        <thead>
          <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Pelanggan</th>
            <th scope="col">Tanggal</th>
            <th scope="col">Status Pembelian</th>
            <th scope="col">Total</th>
          </tr>
        </thead>
          <tbody>
            <?php $nomor=1; ?>
            <?php $ambil=$koneksi_db->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.id_pelanggan=pelanggan.id_pelanggan"); ?>
            <?php while ($pecah = $ambil->fetch_assoc()) { ?>
          	<tr>
              <td><?php echo $nomor; ?></td>
          		<td><?php echo $pecah['nama_pelanggan']; ?></td>
              <td><?php echo $pecah['tanggal_pembelian']; ?></td>
              <td><?php echo $pecah['status_pembelian']; ?></td>
              <td><?php echo $pecah['total_pembelian']; ?></td>
          		<td>
                  <?php if ($pecah['status_pembelian']=="sudah kirim pembayaran"): ?>
                  <a href="index.php?show=pembayaran&id=<?php echo $pecah['id_pembelian'] ?>" class="btn btn-secondary btn-xs">Pembayaran</a>
                <?php endif ?>
                </td>
          	</tr>
            <?php $nomor++; ?>
            <?php } ?>
          </tbody>
      </table>