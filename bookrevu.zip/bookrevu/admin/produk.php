<?php
    $ambil = $koneksi_db->query("SELECT * FROM tbl_produk");
    $count = 1;
?>
<h2 style="font-family: Ink free; color: #87CEEB;"><i class="fas fa-utensils mt-2"></i><b> Kelola Produk</b></h2><hr>
<?php
    $edit = isset($_GET["edit"]);
    $baru = isset($_GET["baru"]);
    
    if($edit || $baru):
?>
<form action="s_produk.php" method="post" enctype='multipart/form-data'>
    <?php if($baru): ?>
    <input type="hidden" name="action" value="baru">
    <?php elseif($edit): ?>
    <input type="hidden" name="action" value="edit">
    <?php endif; ?>
    <div class="form-group">
        <label for="id">ID Produk</label>
        <input type="text" class="form-control" name="id" id="id" value="<?= $_GET["id"] ?? '' ?>" placeholder="AUTO" required readonly>
    </div>
    <div class="form-group">
        <label for="nama_produk">Nama Produk</label>
        <input type="text" class="form-control" name="nama_produk" id="nama_produk" value="<?= $_GET["nama_produk"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="harga_produk">Harga Produk</label>
        <input type="number" class="form-control" name="harga_produk" id="harga_produk" value="<?= $_GET["harga_produk"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="deskripsi_produk">Deskripsi Produk</label>
        <input type="text" class="form-control" name="deskripsi_produk" id="deskripsi_produk" value="<?= $_GET["deskripsi_produk"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="deskripsi_produk">Foto Produk</label>
        <input type="file" class="form-control" name="foto_produk" id="foto_produk" accept="image/*" onchange="loadFile(event)">
        <img id="output" class="card" height="200px" src="<?= '../img/'. ($_GET["foto_produk"] ?? '') ?>" alt="Foto Produk" />
        <script>
            var loadFile = function(event) {
                var output = document.getElementById('output');
                output.src = URL.createObjectURL(event.target.files[0]);
                output.onload = function() {
                URL.revokeObjectURL(output.src) // free memory
                }
            };
        </script>
    </div>
    <div class="form-group">
        <?php if($baru): ?>
        <input type="submit" class="form-control btn btn-primary" value="Baru">
        <?php elseif($edit): ?>
        <input type="submit" class="form-control btn btn-primary" value="Edit">
        <?php endif; ?>
    </div>
    <div class="form-group">
        <button type="button" class="form-control btn btn-danger" onclick="window.history.back();">Cancel</button>
    </div>
</form>
<?php else: ?>
<?php endif; ?>
<div class="table-responsive">
    <table class="table table-striped mt-4" style="background-color: var(--primary-color) !important; font-family: Ink Free;">
        <thead>
            <tr>
                <th>#</th>
                <th>ID Produk</th>
                <th>Nama Produk</th>
                <th>Harga Produk</th>
                <th>Deskripsi Produk</th>
                <th>Foto Produk</th>
                <th>Action</th>
            </tr>			
        </thead>
        <tbody>
            <?php
                while($data = $ambil->fetch_assoc()):
                $id = $data["id_produk"];
            ?>
            <tr>
                <td><?= $count++ ?></td>
                <td><?= $id ?></td>
                <td><?= $data["nama_produk"] ?></td>
                <td><?= $data["harga_produk"] ?></td>
                <td><?= $data["deskripsi_produk"] ?></td>
                <td><img height="60px" width="100px" src="../img/<?= $data["foto_produk"] ?>" alt="<?= $data["foto_produk"] ?>"></td>
                <td>
                    <form id="form_input" method="get">
                        <input type="hidden" name="show" value="produk">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="hidden" name="nama_produk" value="<?= $data["nama_produk"] ?>">
                        <input type="hidden" name="harga_produk" value="<?= $data["harga_produk"] ?>">
                        <input type="hidden" name="deskripsi_produk" value="<?= $data["deskripsi_produk"] ?>">
                        <input type="hidden" name="foto_produk" value="<?= $data["foto_produk"] ?>">
                        <button class="btn btn-primary" name="edit" value="1"><i class="fas fa-pencil-alt"></i>  Edit</button>
                        <button class="btn btn-danger" type="button" onclick="hapus_data('produk', <?= $id ?>)"><i class="fas fa-trash"></i> Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
            <tr>
        </tbody>
    </table>
</div>

<form action="" method="get">
    <input type="hidden" name="show" value="produk">
    <input type="hidden" name="baru" value="1">
    <button class="btn btn-primary">Baru</button>
</form>

<?php
    if(isset($_GET['error'])){
        $error = $_GET['error'];
        $errmsg = "Terjadi kesalahan, cek data dan coba beberapa saat lagi!";
        if($error == 2){
            $errmsg = 'Pilih Foto Produk terlebih dahulu!';
        }
        echo "<script>
                alert('$errmsg');
                window.history.back();
            </script>";
    }
?>