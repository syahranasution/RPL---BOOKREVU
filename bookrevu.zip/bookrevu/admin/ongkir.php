<?php
    $ambil = $koneksi_db->query("SELECT * FROM ongkir");
    $count = 1;
?>
<h2 style="font-family: Ink free; color: #87CEEB;"><i class="fas fa-shipping-fast mt-2"></i><b> Kelola Ongkir</b></h2><hr>
<?php
    $edit = isset($_GET["edit"]);
    $baru = isset($_GET["baru"]);
    
    if($edit || $baru):
?>
<form action="s_ongkir.php" method="post">
    <?php if($baru): ?>
    <input type="hidden" name="action" value="baru">
    <?php elseif($edit): ?>
    <input type="hidden" name="action" value="edit">
    <?php endif; ?>
    <div class="form-group">
        <label for="id">ID Ongkir</label>
        <input type="text" class="form-control" name="id" id="id" value="<?= $_GET["id"] ?? '' ?>" placeholder="AUTO" required readonly>
    </div>
    <div class="form-group">
        <label for="nama_kota">Nama Kota</label>
        <input type="text" class="form-control" name="nama_kota" id="nama_kota" value="<?= $_GET["nama_kota"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="tarif">Tarif</label>
        <input type="number" class="form-control" name="tarif" id="tarif" value="<?= $_GET["tarif"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <?php if($baru): ?>
        <input type="submit" class="form-control btn btn-primary" value="Baru">
        <?php elseif($edit): ?>
        <input type="submit" class="form-control btn btn-primary" value="Edit">
        <?php endif; ?>
    </div>
    <div class="form-group">
        <button type="button" class="form-control btn btn-danger" onclick="window.history.back();">Cancel</button>
    </div>
</form>
<?php else: ?>
    <form action="" method="get">
        <input type="hidden" name="show" value="ongkir">
        <input type="hidden" name="baru" value="1">
        <button class="btn btn-primary">Baru</button>
    </form>
<?php endif; ?>
<div class="table-responsive">
   <table class="table table-striped mt-4" style="background-color: #87CEEB; font-family: Ink Free;">
        <thead>
            <tr>
                <th>#</th>
                <th>ID Ongkir</th>
                <th>Nama Kota</th>
                <th>Tarif</th>
                <th>Action</th>
            </tr>			
        </thead>
        <tbody>
            <?php
                while($perproduk = $ambil->fetch_assoc()):
                $id = $perproduk["id_ongkir"];
            ?>
            <tr>
                <td><?= $count++ ?></td>
                <td><?= $id ?></td>
                <td><?= $perproduk["nama_kota"] ?></td>
                <td><?= $perproduk["tarif"] ?></td>
                <td>
                    <form id="form_input" method="get">
                        <input type="hidden" name="show" value="ongkir">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="hidden" name="nama_kota" value="<?= $perproduk["nama_kota"] ?>">
                        <input type="hidden" name="tarif" value="<?= $perproduk["tarif"] ?>">
                        <button class="btn btn-primary" name="edit" value="1"><i class="fas fa-pencil-alt"></i>  Edit</button>
                        <button class="btn btn-danger" type="button" onclick="hapus_data('ongkir', <?= $id ?>)"><i class="fas fa-trash"></i>  Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
            <tr>
        </tbody>
    </table>
</div>
<?php
    if(isset($_GET['error'])){
        $error = $_GET['error'];
        $errmsg = "Terjadi kesalahan, cek data dan coba beberapa saat lagi!";
        echo "<script>
                alert('$errmsg');
                window.history.back();
            </script>";
    }
?>