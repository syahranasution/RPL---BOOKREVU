<?php
    $ambil = $koneksi_db->query("SELECT * FROM pelanggan");
    $count = 1;
?>
<h2 style="font-family: Ink free; color: #87CEEB;"><i class="fas fa-user mt-2"></i><b> Kelola Pelanggan</b></h2><hr>
<?php
    $edit = isset($_GET["edit"]);
    $baru = isset($_GET["baru"]);
    
    if($edit || $baru):
?>
<form action="s_pelanggan.php" method="post">
    <?php if($baru): ?>
    <input type="hidden" name="action" value="baru">
    <?php elseif($edit): ?>
    <input type="hidden" name="action" value="edit">
    <?php endif; ?>
    <div class="form-group">
        <label for="id">ID Pelanggan</label>
        <input type="text" class="form-control" name="id" id="id" value="<?= $_GET["id"] ?? '' ?>" placeholder="AUTO" required readonly>
    </div>
    <div class="form-group">
        <label for="email_pelanggan">Email pelanggan</label>
        <input type="email" class="form-control" name="email_pelanggan" id="email_pelanggan" value="<?= $_GET["email_pelanggan"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="nama_pelanggan">Nama Lengkap</label>
        <input type="text" class="form-control" name="nama_pelanggan" id="nama_pelanggan" value="<?= $_GET["nama_pelanggan"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="telpon_pelanggan">Telpon Pelanggan</label>
        <input type="text" class="form-control" name="telpon_pelanggan" id="telpon_pelanggan" value="<?= $_GET["telpon_pelanggan"] ?? '' ?>" required>
    </div>
    <div class="form-group">
        <label for="level">Level</label>
        <select class="form-control" name="level" id="level" required>
            <option value="customer">Customer</option>
        </select>
    </div>
    <div class="form-group">
        <?php if($baru): ?>
        <input type="submit" class="form-control btn btn-primary" value="Baru">
        <?php elseif($edit): ?>
        <input type="submit" class="form-control btn btn-primary" value="Edit">
        <?php endif; ?>
    </div>
    <div class="form-group">
        <button type="button" class="form-control btn btn-danger" onclick="window.history.back();">Cancel</button>
    </div>
</form>
<!-- <?php //else: ?>
    <form action="" method="get">
        <input type="hidden" name="show" value="pelanggan">
        <input type="hidden" name="baru" value="1">
        <button class="btn btn-primary">Baru</button>
    </form> -->
<?php endif; ?>
<div class="table-responsive">
    <table class="table table-striped mt-4" style="background-color: #87CEEB; font-family: Ink Free;">       
     <thead>
            <tr>
                <th>#</th>
                <th>ID Pelanggan</th>
                <th>Email Pelanggan</th>
                <th>Nama Lengkap</th>
                <th>Telpon Pelanggan</th>
                <th>Level</th>
                <th>Action</th>
            </tr>			
        </thead>
        <tbody>
            <?php
                while($data = $ambil->fetch_assoc()):
                $id = $data["id_pelanggan"];
            ?>
            <tr>
                <td><?= $count++ ?></td>
                <td><?= $id ?></td>
                <td><?= $data["email_pelanggan"] ?></td>
                <td><?= $data["nama_pelanggan"] ?></td>
                <td><?= $data["telpon_pelanggan"] ?></td>
                <td><?= $data["level"] ?></td>
                <td>
                    <form id="form_input" method="get">
                        <input type="hidden" name="show" value="pelanggan">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="hidden" name="email_pelanggan" value="<?= $data["email_pelanggan"] ?>">
                        <input type="hidden" name="nama_pelanggan" value="<?= $data["nama_pelanggan"] ?>">
                        <input type="hidden" name="telpon_pelanggan" value="<?= $data["telpon_pelanggan"] ?>">
                        <input type="hidden" name="level" value="<?= $data["level"] ?>">
                        <button class="btn btn-primary" name="edit" value="1"><i class="fas fa-pencil-alt"></i>  Edit</button>
                        <button class="btn btn-danger" type="button" onclick="hapus_data('pelanggan', <?= $id ?>)"><i class="fas fa-trash"></i>  Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
            <tr>
        </tbody>
    </table>
</div>
<?php
    if(isset($_GET['error'])){
        $error = $_GET['error'];
        $errmsg = "Terjadi kesalahan, cek data dan coba beberapa saat lagi!";
        echo "<script>
                alert('$errmsg');
                window.history.back();
            </script>";
    }
?>