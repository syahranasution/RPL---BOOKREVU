<h3 style="color: var(--primary-color) !important; font-family: Ink Free;"><i class="fas fa-cart-plus mt-4"></i> <b>Data Pembayaran</b></h3><hr>

<?php 

	//mendapatkan id pembelian dari url
	$id_pembelian = $_GET['id'];

	//mengambil data pembayaran berdasarkan id_pembelian
	$ambil = $koneksi_db->query("SELECT * FROM pembayaran WHERE id_pembelian='$id_pembelian'");
	$detail = $ambil->fetch_assoc();

 ?>

 	<div class="row">
 		<div class="col-md-6">
 			<table class="table table-striped ml-3" style="background-color: var(--primary-color) !important; font-family: Ink Free;">
 				<tr>
 					<th>Nama</th>
 					<td><?php echo $detail['nama'] ?></td>
 				</tr><br>
 				<tr>
 					<th>Bank</th>
 					<td><?php echo $detail['bank'] ?></td>
 				</tr>
 				<tr>
 					<th>Jumlah</th>
 					<td>Rp.<?php echo number_format($detail['jumlah'])?></td>
 				</tr>
 				<tr>
 					<th>Tanggal</th>
 					<td><?php echo $detail['tanggal'] ?></td>
 				</tr>
 				<tr>
 					<th>Bukti Pembayaran</th>
 					<td><img src="../bukti_pembayaran/<?php echo $detail['bukti'] ?>" alt="" style="width: 130px; height: 120px;"></td>
 				</tr>
 		</div>
 	</div>

 	<form method="post">
 		<div class="form-group">
 			<label>No Resi Pengiriman</label>
 			<input type="text" class="form-control" name="resi">
 		</div>
 		<div class="form-group">
 			<label>Status</label>
 			<select class="form-control" name="status">
 				<option value="">Pilih Status</option>
 				<option value="lunas">Lunas</option>
 				<option value="barang dikirim">Barang Dikirim</option>
 				<option value="batal">Batal</option>
 			</select>
 		</div>
 		<button class="btn btn-secondary" name="proses">Proses</button>
 	</form>

 	<?php 
 		if (isset($_POST["proses"]))
 		{
 			$resi = $_POST["resi"];
 			$status = $_POST["status"];
 			$query = $koneksi_db->query("UPDATE pembelian SET resi_pengiriman='$resi', status_pembelian='$status' WHERE id_pembelian=$id_pembelian");
 			// echo "<script>alert('$koneksi_db->error');</script>";
 			echo $koneksi_db->error;
 			// echo "<script>alert('Data Pembelian TerUpdate');</script>";
 			// echo "<script>location='index.php?show=pembelian';</script>";
 		}
 	 ?>