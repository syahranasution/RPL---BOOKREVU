<div class="col-md-10 offset-md-2 content">
    <div class="col-md-6">
        <table class="table table-striped ml-3" style="background-color: var(--primary-color) !important; font-family: Ink Free;">
            <tr>
                <th>Nama</th>
                <td><?php echo $datas['nama'] ?></td>
            </tr><br>
            <tr>
                <th>Bank</th>
                <td><?php echo $datas['bank'] ?></td>
            </tr>
            <tr>
                <th>Jumlah</th>
                <td>Rp.<?php echo number_format($datas['jumlah'])?></td>
            </tr>
            <tr>
                <th>Tanggal</th>
                <td><?php echo $datas['tanggal'] ?></td>
            </tr>
            <tr>
                <th>Bukti Pembayaran</th>
                <td><img src="<?= base_url() ?>bukti_pembayaran/<?php echo $datas['bukti'] ?>" alt="bukti" style="width: 130px; height: 120px;"></td>
            </tr>
 	    </table>
    </div>
 	<form action="<?= base_url() ?>ci_admin/proses/pembayaran" method="post">
        <input type="hidden" name="id_pembelian" value="<?= $datas['id_pembelian'] ?>">
 		<div class="form-group">
 			<label for="resi">No Resi Pengiriman</label>
 			<input type="text" class="form-control" name="resi" id="resi">
 		</div>
 		<div class="form-group">
 			<label for="status">Status</label>
 			<select class="form-control" name="status" id="status">
 				<option value="">Pilih Status</option>
 				<option value="lunas">Lunas</option>
 				<option value="barang dikirim">Barang Dikirim</option>
 				<option value="batal">Batal</option>
 			</select>
 		</div>
 		<button class="btn btn-secondary" name="proses">Proses</button>
 	</form>
</div>