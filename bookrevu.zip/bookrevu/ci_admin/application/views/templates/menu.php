<header class="header-admin">
  <div class="container">
    <div class="row">
      <div class="col-md-4 col-sm-12 col-12">
        <!-- <div class="btn-group">
          <button class="btn my-md-4 my-2 text-white"><i class="fab fa-facebook-square m-2"></i></button>
          <button class="btn my-md-4 my-2 text-white"><i class="fab fa-instagram"></i></button>
          <button class="btn my-md-4 my-2 text-white"><i class="fab fa-youtube"></i></button>
        </div> -->
      </div>

        <div class="col-md-4 col-12 text-center">
           <h2 class="my-md-3 site-title text-white"><i class="fas fa-user-lock" data-toggle="tolltip" title="Sign In"></i>  | Halaman Admin</h2>
        </div>
   </div>
  </div>
</header>

<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-admin">
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      
    </div>
  </div>

  <div class="search-wrap">
    <div class="container">
      <a href="#" class="fas fa-times search-close js-search-close"></a>
      <form action="#" method="post">
        <input type="text" class="form-control" id="search-bar" placeholder="Search keyword and hit enter...">
      </form>
    </div>
  </div>

  <div class="navbar-nav">
    <nav class="navbar navbar-light bg-light">
      <li class="nav-item border rounded-cicle mx-2 search-ico">
        <i class="fas fa-search p-2 js-search-open" data-toggle="tooltip" title="Search"></i>
        <!-- <a href="#" class="icons-btn d-inline-block "><span class="icon-search"></span></a> -->
      </li>
    <nav>
  </div>
</nav>


<div class="row no-gutters">
        <div class="col-md-2 bg-light sidebar">
          <div class="sidebar-sticky">
            <ul class="list-group list-group-flush">
              <li class="list-group-item" style="background-color: var(--primary-color) !important; color: white;"><i class="fas fa-list-ul m-2"></i>ADMIN</li><br>
              <img src="<?= base_url() ?>img/admin/admin.jpg" width="200"><br>
              <a href="<?= base_url() ?>ci_admin" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-home p-2"></i>DASHBOARD</a>
              <a href="<?= base_url() ?>ci_admin/show/admin" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-user-lock p-2"></i>ADMIN</a>
              <a href="<?= base_url() ?>ci_admin/show/ongkir" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-shipping-fast p-2"></i>ONGKIR</a>
              <a href="<?= base_url() ?>ci_admin/show/pelanggan" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-user p-2"></i>PELANGGAN</a>
              <a href="<?= base_url() ?>ci_admin/show/produk" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-utensils p-2"></i>PRODUK</a>
              <a href="<?= base_url() ?>ci_admin/show/pembelian" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-cash-register p-2"></i>PEMBELIAN</a>
              <a href="<?= base_url() ?>ci_admin/show/laporan" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-file p-2"></i>LAPORAN</a>
              <a href="<?= base_url() ?>ci_admin/proses/logout" class="list-group-item list-group-item-action" style="color: grey;"><i class="fas fa-tachometer-alt m-2"></i>LOGOUT</a>
            </ul>
          </div>
      </div>
    </div>