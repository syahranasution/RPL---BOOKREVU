<div class="col-md-10 offset-md-2 content">
    <h3 style="color: var(--primary-color) !important; font-family: Ink Free;"><i class="fas fa-cart-plus"></i> <b>Data Pembelian</b></h3><hr>
    <table class="table table-striped" style="background-color: var(--primary-color) !important; font-family: Ink Free; width: 1000px; margin-left: 20px;">
        <thead>
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Pelanggan</th>
            <th scope="col">Tanggal</th>
            <th scope="col">Status Pembelian</th>
            <th scope="col">Total</th>
        </tr>
        </thead>
        <tbody>
            <?php $nomor=1; ?>
            <?php foreach ($datas as $key => $data): ?>
            <tr>
            <td><?= $nomor; ?></td>
            <td class="searched"><?= $data['nama_pelanggan']; ?></td>
            <td class="searched"><?= $data['tanggal_pembelian']; ?></td>
            <td class="searched"><?= $data['status_pembelian']; ?></td>
            <td class="searched"><?= $data['total_pembelian']; ?></td>
                <td>
                <?php if ($data['status_pembelian']=="sudah kirim pembayaran"): ?>
                <a href="<?= base_url() ?>ci_admin/show/pembayaran/<?= $data['id_pembelian'] ?>" class="btn btn-secondary btn-xs">Pembayaran</a>
                <?php endif ?>
                </td>
            </tr>
            <?php $nomor++; ?>
            <?php endforeach ?>
        </tbody>
    </table>
	<?php
	    if(isset($_GET['error'])){
	        $error = $_GET['error'];
	        $errmsg = "Terjadi kesalahan, cek data dan coba beberapa saat lagi!";
	        echo "<script>
	                alert('$errmsg');
	                window.history.back();
	            </script>";
	    }
	?>
</div>