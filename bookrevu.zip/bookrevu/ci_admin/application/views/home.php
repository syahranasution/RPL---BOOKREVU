<div class="col-md-10 offset-md-2 content">
    <div class="row">
        <h2><i class="fas fa-home"></i>  Dashboard</h2>
    </div>
    <div class="row d-flex flex-row justify-content-around">
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = '<?= base_url() ?>ci_admin/show/admin';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Admin</b></h4>
                    <i class="fas fa-user-lock fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data : <?= $admin ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = '<?= base_url() ?>ci_admin/show/ongkir';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Ongkir</b></h4>
                    <i class="fas fa-shipping-fast fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $ongkir ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = '<?= base_url() ?>ci_admin/show/pelanggan';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Pelanggan</b></h4>
                    <i class="fas fa-users fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $pelanggan ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = '<?= base_url() ?>ci_admin/show/produk';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Produk</b></h4>
                    <i class="fas fa-utensils fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $produk ?>
                </div>
            </div>
        </div>
        <div class="card col-md-2 text-white bg-primary-color" onclick="location.href = '<?= base_url() ?>ci_admin/show/pembelian';">
            <div class="card-body">
                <div class="card-title text-center">
                    <h4 style="font-family: Ink free;"><b>Pembelian</b></h4>
                    <i class="fas fa-cash-register fa-2x"></i>
                </div>
                <div class="card-subtitle">
                    Jumlah Data: <?= $pembelian ?>
                </div>
            </div>
        </div>
    </div>
</div>