<div class="col-md-4 offset-md-4 content">
    <h2>Silahkan Login</h2>
    <form action="<?= base_url() ?>ci_admin/show/login" method="post">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" name="username" id="username" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
        </div>
        <div class="form-group">
            <input type="submit" class="form-control btn btn-primary" name="login" value="Login">
        </div>
        <div class="form-group">
            <button type="button" class="form-control btn btn-danger" onclick="window.history.back();">Cancel</button>
        </div>
    </form>
</div>