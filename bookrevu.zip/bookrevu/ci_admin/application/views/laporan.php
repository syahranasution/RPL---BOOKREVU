<div class="col-md-8 offset-md-3 content">
    <p><b style="font-family: Ink Free; color: #87CEEB;"><center><h3><i class="fas fa-file"></i> Laporan Pembelian Dari <?php echo $tgl_mulai ?> Hingga <?php echo $tgl_selesai ?></h3></center></b></p>
    <hr>
    <form action="<?= base_url() ?>ci_admin/show/laporan" method="post">
        <div class="row">
            <div class="col-md-5">
                <div class="form-group">
                    <label>Tanggal Mulai</label>
                    <input type="date" class="form-control" name="tglm" value="<?php echo $tgl_mulai ?>">
                </div>
            </div>
            <div class="col-md-5">
                <div class="form-group">
                    <label>Tanggal Selesai</label>
                    <input type="date" class="form-control" name="tgls" value="<?php echo $tgl_selesai ?>">
                </div>
            </div>
            <div class="col-md-2">
                <label>&nbsp;</label><br>
                <button class="btn btn-primary" name="kirim">Lihat</button>
            </div>
        </div>
    </form>

    <table class="table table-striped" style="background-color: var(--primary-color) !important; font-family: Ink Free;">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Pelanggan</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Jumlah</th>
                <th scope="col">Status</th>
            </tr>
        </thead>
        <tbody>
        <?php $total=0; ?>
        <?php foreach ($pembelians as $key => $pembelian): ?>
        <?php $total+=$pembelian ['total_pembelian'] ?>
            <tr>
                <td><?php echo $key+1 ?></td>
                <td><?php echo $pembelian["nama_pelanggan"] ?></td>
                <td><?php echo $pembelian["tanggal_pembelian"] ?></td>
                <td><?php echo number_format($pembelian["total_pembelian"]) ?></td>
                <td><?php echo $pembelian["status_pembelian"] ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3">Total :</th>
                <th>Rp. <?php echo number_format($total) ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>
<div>