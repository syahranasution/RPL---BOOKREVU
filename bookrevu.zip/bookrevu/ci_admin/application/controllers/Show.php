<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Show extends CI_Controller {

	public function index()
	{
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['admin'] = count($this->AdminModel->get_all());
		$data['ongkir'] = count($this->OngkirModel->get_all());
		$data['pelanggan'] = count($this->PelangganModel->get_all());
		$data['produk'] = count($this->ProdukModel->get_all());
		$data['pembelian'] = count($this->PembelianModel->get_all());
		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('home', $data);
		$this->load->view('templates/footer');
	}

	public function login()
	{
		if($this->input->post('login')){
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$redir = $this->input->post('redir');
			$user = $this->AdminModel->login($username, $password);
			$this->session->set_userdata(['user' => $user]);
			redirect(base_url().'ci_admin/show/');
		}else{
			$this->load->view('templates/header');
			$this->load->view('login');
		}
	}
	
	public function admin($action = null){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->AdminModel->get_all();
		$data['action'] = $action;

		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('admin', $data);
		$this->load->view('templates/footer');
	}
	
	public function ongkir($action = null){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->OngkirModel->get_all();
		$data['action'] = $action;

		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('ongkir', $data);
		$this->load->view('templates/footer');
	}

	public function pelanggan($action = null){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->PelangganModel->get_all();
		$data['action'] = $action;

		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('pelanggan', $data);
		$this->load->view('templates/footer');
	}
	
	public function produk($action = null){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->ProdukModel->get_all();
		$data['action'] = $action;

		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('produk', $data);
		$this->load->view('templates/footer');
	}
	
	public function pembelian(){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->PembelianModel->get_all();
		$this->PembelianModel->clear_old();
		
		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('pembelian', $data);
		$this->load->view('templates/footer');
	}
	
	public function pembayaran($id){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}
		$data['datas'] = $this->PembelianModel->get_by_id($id);

		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('pembayaran', $data);
		$this->load->view('templates/footer');
	}
	
	public function laporan(){
		if(!$this->session->has_userdata('user')){
			redirect(base_url().'ci_admin/show/login');
		}

		$data['pembelians'] = array();
		$data['tgl_mulai'] = "-";
		$data['tgl_selesai'] = "-";

		if ($this->input->post('kirim') !== null){
			$data['pembelians'] = $this->PembelianModel->get_laporan($this->input->post('tglm'), $this->input->post('tgls'));
			$data['tgl_mulai'] = $this->input->post('tglm');
			$data['tgl_selesai'] = $this->input->post('tgls');
		}
		$this->load->view('templates/header');
		$this->load->view('templates/menu');
		$this->load->view('laporan', $data);
		$this->load->view('templates/footer');
	}
}
