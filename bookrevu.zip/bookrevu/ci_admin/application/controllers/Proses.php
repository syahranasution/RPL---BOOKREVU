<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Proses extends CI_Controller
{

	public function index()
	{
		redirect(base_url() . 'ci_admin/show');
	}

	public function admin($action = null, $id = -1)
	{
		if (isset($action)) {
			$action = $action;
			if ($action == 'hapus') {
				$query = $this->AdminModel->hapus($id);
			} else {
				$id = $this->input->post('id');
				$username = $this->input->post('username');
				$nama = $this->input->post('nama_lengkap');
				if ($this->input->post('password') != '') {
					$pass = $this->input->post('password');
					$pass_c = $this->input->post('password_c');
					if ($pass != $pass_c) {
						redirect(base_url() . 'ci_admin/show/admin?error=2');
						exit();
					}
				}

				if ($action == 'edit') {
					if (isset($pass)) {
						$query = $this->AdminModel->ubah_pass($id, $username, $nama, $pass);
					} else {
						$query = $this->AdminModel->ubah($id, $username, $nama);
					}
				} else if ($action == 'baru') {
					$query = $this->AdminModel->baru($username, $nama, $pass);
				}
			}
		}
		if ($query) {
			redirect(base_url() . 'ci_admin/show/admin');
		} else {
			print_r(mysqli_error($koneksi_db));
			redirect(base_url() . 'ci_admin/show/admin?error=1');
		}
	}

	public function ongkir($action = null, $id = -1)
	{
		if (isset($action)) {
			$action = $action;
			if ($action == 'hapus') {
				$query = $this->OngkirModel->hapus($id);
			} else {
				$id = $this->input->post('id');
				$kota = $this->input->post('nama_kota');
				$kecamatan = $this->input->post('nama_kecamatan');
				$tarif = $this->input->post('tarif');
				if ($action == 'edit') {
					$query = $this->OngkirModel->ubah($id, $kota, $kecamatan, $tarif);
				} else if ($action == 'baru') {
					$query = $this->OngkirModel->baru($kota, $kecamatan, $tarif);
				}
			}
		}
		if ($query) {
			redirect(base_url() . 'ci_admin/show/ongkir');
		} else {
			print_r(mysqli_error($koneksi_db));
			redirect(base_url() . 'ci_admin/show/ongkir?error=1');
		}
	}

	public function pelanggan($action = null, $id = -1)
	{
		if (isset($action)) {
			$action = $action;
			if ($action == 'hapus') {
				$query = $this->PelangganModel->hapus($id);
			} else {
				$id = $this->input->post('id');
				$email = $this->input->post('email_pelanggan');
				$nama = $this->input->post('nama_pelanggan');
				$telp = $this->input->post('telpon_pelanggan');
				$level = $this->input->post('level');
				if ($action == 'edit') {
					$query = $this->PelangganModel->ubah($id, $email, $nama, $telp, $level);
				} else if ($action == 'baru') {
					$query = $this->PelangganModel->baru($email, $nama, $telp, $level);
				}
			}
		}
		if ($query) {
			redirect(base_url() . 'ci_admin/show/pelanggan');
		} else {
			print_r(mysqli_error($koneksi_db));
			redirect(base_url() . 'ci_admin/show/pelanggan?error=1');
		}
	}

	public function produk($action = null, $id = -1)
	{
		if (isset($action)) {
			$action = $action;
			if ($action == 'hapus') {
				$query = $this->ProdukModel->hapus($id);
			} else {
				$id = $this->input->post('id');
				$nama = $this->input->post('nama_produk');
				$harga = $this->input->post('harga_produk');
				$deskripsi = $this->input->post('deskripsi_produk');

				$config['file_name'] = $nama . time();
				$config['upload_path'] = str_replace('ci_admin', 'img', FCPATH);
				$config['allowed_types'] = 'gif|jpg|png';
				$config['overwrite'] = true;
				$config['file_ext_tolower'] = true;
				$this->upload->initialize($config);

				if ($action == 'edit') {
					if (!$this->upload->do_upload('foto_produk')) {
						$query = $this->ProdukModel->ubah($id, $nama, $harga, $deskripsi);
					} else {
						$file = array('image_metadata' => $this->upload->data());
						$query = $this->ProdukModel->ubah_foto($id, $nama, $harga, $deskripsi, $file['image_metadata']['file_name']);
					}
				} else if ($action == 'baru') {
					if (!$this->upload->do_upload('foto_produk')) {
						redirect(base_url() . 'ci_admin/show/produk?error=2');
					} else {
						$file = array('image_metadata' => $this->upload->data());
						$query = $this->ProdukModel->baru($nama, $harga, $deskripsi, $file['image_metadata']['file_name']);
					}
				}
			}
		}
		if ($query) {
			redirect(base_url() . 'ci_admin/show/produk');
		} else {
			print_r(mysqli_error($koneksi_db));
			redirect(base_url() . 'ci_admin/show/produk?error=1');
		}
	}

	public function pembayaran()
	{
		$id_pembelian = $this->input->post('id_pembelian');
		$resi = $this->input->post('resi');
		$status = $this->input->post('status');
		if ($this->PembelianModel->pembayaran($id_pembelian, $resi, $status)) {
			redirect(base_url() . 'ci_admin/show/pembelian');
		} else {
			redirect(base_url() . 'ci_admin/show/pembelian?error=1');
		}
	}

	public function logout()
	{
		if ($this->session->has_userdata('user')) {
			$this->session->sess_destroy();
			redirect(base_url());
		} else {
			redirect(base_url() . 'ci_admin/show/');
		}
	}
}
