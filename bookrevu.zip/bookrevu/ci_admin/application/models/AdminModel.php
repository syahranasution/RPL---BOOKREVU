<?php

class AdminModel extends CI_Model{
	public function get_all(){
		$query = $this->db->select('*')
							->from('admin')
							->get()->result_array();
		return $query;
	}

	public function baru($username, $nama_lengkap, $password){
		$query = $this->db->set('username', $username)
							->set('nama_lengkap', $nama_lengkap)
							->set('password', $password)
							->insert('admin');
		return true;
	}

	public function hapus($id_admin){
		$query = $this->db->where('id_admin', $id_admin)
							->delete('admin');
		return true;
	}

	public function ubah_pass($id_admin, $username, $nama_lengkap, $password){
		$query = $this->db->set('username', $username)
							->set('nama_lengkap', $nama_lengkap)
							->set('password', $password)
							->where('id_admin', $id_admin)
							->update('admin');
		return true;
	}
	public function ubah($id_admin, $username, $nama_lengkap){
		$query = $this->db->set('username', $username)
							->set('nama_lengkap', $nama_lengkap)
							->where('id_admin', $id_admin)
							->update('admin');
		return true;
	}

	public function login($username, $password){
		$query = $this->db->select('*')
							->from('admin')
							->where('username', $username)
							->where('password', $password)
							->get()->row_array();
		return $query;
	}
}