<?php

class ProdukModel extends CI_Model{
	public function get_all(){
		$query = $this->db->select('*')
							->from('tbl_produk')
							->get()->result_array();
		return $query;
	}

	public function baru($nama_produk, $harga, $deskripsi, $foto){
		$query = $this->db->set('nama_produk', $nama_produk)
							->set('harga_produk', $harga)
							->set('deskripsi_produk', $deskripsi)
							->set('foto_produk', $foto)
							->insert('tbl_produk');
		return true;
	}

	public function hapus($id_produk){
		$query = $this->db->where('id_produk', $id_produk)
							->delete('tbl_produk');
		return true;
	}

	public function ubah($id_produk, $nama_produk, $harga, $deskripsi){
		$query = $this->db->set('nama_produk', $nama_produk)
							->set('harga_produk', $harga)
							->set('deskripsi_produk', $deskripsi)
							->where('id_produk', $id_produk)
							->update('tbl_produk');
		return true;
	}

	public function ubah_foto($id_produk, $nama_produk, $harga, $deskripsi, $foto){
		$query = $this->db->set('nama_produk', $nama_produk)
							->set('harga_produk', $harga)
							->set('deskripsi_produk', $deskripsi)
							->set('foto_produk', $foto)
							->where('id_produk', $id_produk)
							->update('tbl_produk');
		return true;
	}
}