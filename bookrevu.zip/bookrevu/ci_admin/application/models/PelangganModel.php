<?php

class PelangganModel extends CI_Model{
	public function get_all(){
		$query = $this->db->select('*')
							->from('pelanggan')
							->get()->result_array();
		return $query;
	}

	public function baru($email_pelanggan, $nama_pelanggan, $telpon_pelanggan, $level){
		$query = $this->db->set('email_pelanggan', $email_pelanggan)
							->set('nama_pelanggan', $nama_pelanggan)
							->set('telpon_pelanggan', $telpon_pelanggan)
							->set('level', $level)
							->insert('pelanggan');
		return true;
	}

	public function hapus($id_pelanggan){
		$query = $this->db->where('id_pelanggan', $id_pelanggan)
							->delete('pelanggan');
		return true;
	}

	public function ubah($id_pelanggan, $email_pelanggan, $nama_pelanggan, $telpon_pelanggan, $level){
		$query = $this->db->set('email_pelanggan', $email_pelanggan)
							->set('nama_pelanggan', $nama_pelanggan)
							->set('telpon_pelanggan', $telpon_pelanggan)
                            ->set('level', $level)
                            ->where('id_pelanggan', $id_pelanggan)
							->update('pelanggan');
		return true;
	}
}