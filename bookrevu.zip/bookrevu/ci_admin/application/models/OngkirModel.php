<?php

class OngkirModel extends CI_Model{
	public function get_all(){
		$query = $this->db->select('*')
							->from('ongkir')
							->get()->result_array();
		return $query;
	}

	public function baru($nama_kota, $nama_kecamatan, $tarif){
		$query = $this->db->set('nama_kota', $nama_kota)
							->set('nama_kecamatan', $nama_kecamatan)
							->set('tarif', $tarif)
							->insert('ongkir');
		return true;
	}

	public function hapus($id_ongkir){
		$query = $this->db->where('id_ongkir', $id_ongkir)
							->delete('ongkir');
		return true;
	}

	public function ubah($id_ongkir, $nama_kota, $nama_kecamatan, $tarif){
		$query = $this->db->set('nama_kota', $nama_kota)
							->set('nama_kecamatan', $nama_kecamatan)
							->set('tarif', $tarif)
							->where('id_ongkir', $id_ongkir)
							->update('ongkir');
		return true;
	}
}