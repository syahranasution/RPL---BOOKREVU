<?php

class PembelianModel extends CI_Model{
	public function get_all(){
		$query = $this->db->select('*')
                            ->from('pembelian')
							->join('pelanggan', 'pembelian.id_pelanggan=pelanggan.id_pelanggan')
							->where('id_pembelian IN (SELECT id_pembelian FROM pembayaran)')
							->order_by('id_pembelian', 'desc')
							->get()->result_array();
		return $query;
    }
    
	public function get_by_id($id_pembelian){
		$query = $this->db->select('*')
                            ->from('pembayaran')
                            ->where('id_pembelian', $id_pembelian)
							->get()->row_array();
		return $query;
	}
    
	public function get_laporan($tgl_mulai, $tgl_selesai){
		$query = $this->db->select('*')
							->from('pembelian')
							->join('pelanggan', 'pembelian.id_pelanggan=pelanggan.id_pelanggan', 'left')
							->where('tanggal_pembelian >=', $tgl_mulai)
							->where('tanggal_pembelian <=', $tgl_selesai)
							->get()->result_array();
		return $query;
	}

	public function pembayaran($id_pembelian, $resi, $status){
		$query = $this->db->set('resi_pengiriman', $resi)
							->set('status_pembelian', $status)
                            ->where('id_pembelian', $id_pembelian)
							->update('pembelian');
		return $query;
	}

	public function clear_old(){
		$queryu = $this->db->set('status_pembelian', 'batal')
							->where("id_pembelian NOT IN (SELECT id_pembelian FROM pembayaran) AND tanggal_pembelian <= DATE_SUB(NOW(), INTERVAL 1 DAY)")
							->update('pembelian');
		$queryd = $this->db->where("id_pembelian NOT IN (SELECT id_pembelian FROM pembayaran) AND tanggal_pembelian <= DATE_SUB(NOW(), INTERVAL 2 DAY) AND status_pembelian = 'batal'")
							->delete('pembelian');
	}
}